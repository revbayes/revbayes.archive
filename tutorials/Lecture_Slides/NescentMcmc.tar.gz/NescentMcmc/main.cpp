#include <cmath>
#include <iomanip>
#include <iostream>
#include "MbRandom.h"



int main(int argc, const char* argv[]) {

    // get a random number generator called ran
    MbRandom ran = MbRandom();
    
    // user interface
    int numTosses      = 100;
    int numHeads       = 35;
    int numTails       = numTosses - numHeads;
    int chainLength    = 1000000;
    double window      = 0.1;
    int printFrequency = 1000;
    
    // run Markov chain
    int bins[100];
    for (int i=0; i<100; i++)
        bins[i] = 0;
    double theta = ran.uniformRv();
    for (int n=1; n<=chainLength; n++)
        {
        // propose a new value for theta, called thetaPrime
        double thetaPrime = theta + (ran.uniformRv()-0.5)*window;
        if (thetaPrime < 0.0)
            thetaPrime = -thetaPrime;
        else if (thetaPrime > 1.0)
            thetaPrime = 2.0 - thetaPrime;
        
        // calculate the probability of accepting thetaPrime
        // as the next state of the Markov chain
        double lnLikelihoodRatio = (numHeads*log(thetaPrime) + numTails*log(1.0-thetaPrime)) -
                                   (numHeads*log(theta     ) + numTails*log(1.0-theta     ));
        double lnPriorRatio = 0.0;
        double lnProposalRatio = 0.0;
        double lnR = lnLikelihoodRatio + lnPriorRatio + lnProposalRatio;
        double R = 0.0;
        if (lnR < -300.0)
            R = 0.0;
        else if (lnR > 0.0)
            R = 1.0;
        else
            R = exp(lnR);
        
        // accept or reject thetaPrime
        double u = ran.uniformRv();
        if (u < R)
            theta = thetaPrime;
            
        // print to the screen, maybe
        if (n % printFrequency == 0)
            std::cout << n << " -- " << theta << std::endl;
            
        // remember where the chain is
        bins[(int)(theta*100.0)]++;
        }
    
    // print our frequency histogram
    double cumulativeProb = 0.0;
    for (int i=0; i<100; i++)
        {
        std::cout << std::fixed << std::setprecision(2);
        std::cout << i*0.01 << "-" << (i+1)*0.01 << " -- ";
        std::cout << std::fixed << std::setprecision(4);
        cumulativeProb += (double)bins[i] / chainLength;
        std::cout << (double)bins[i] / chainLength << " ";
        std::cout << cumulativeProb;
        std::cout << std::endl;
        }
    
    return 0;
}

